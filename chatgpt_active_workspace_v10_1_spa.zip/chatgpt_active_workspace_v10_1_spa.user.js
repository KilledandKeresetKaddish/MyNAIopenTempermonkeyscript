// ==UserScript==
// @name         ChatGPT Active Workspace v10.1 SPA (Firefox/Tampermonkey)
// @namespace    https://chatgpt.com/
// @version      10.1.0
// @description  Compact ChatGPT sidebar workspace with folders, persistent chat cache, resilient remounting, and native-SPA chat switching when ChatGPT has the target route mounted.
// @author       Shuu + ChatGPT
// @match        https://chatgpt.com/*
// @match        https://chat.openai.com/*
// @grant        GM_getValue
// @grant        GM_setValue
// @run-at       document-idle
// ==/UserScript==

(() => {
  'use strict';

  const APP_ID = 'shuu-cgpt-workspace-v10';
  const MENU_ID = `${APP_ID}-menu`;
  const STYLE_ID = `${APP_ID}-style`;

  const KEYS = {
    folders: 'shuu_cgpt_workspace_v10_folders',
    assignments: 'shuu_cgpt_workspace_v10_assignments',
    chats: 'shuu_cgpt_workspace_v10_chats',
    ui: 'shuu_cgpt_workspace_v10_ui',
    migrated: 'shuu_cgpt_workspace_v10_migrated'
  };

  const DEFAULT_ACTIVE_ID = 'active';

  const store = {
    get(key, fallback) {
      try {
        const raw = GM_getValue(key);
        if (raw === undefined || raw === null) return fallback;
        if (typeof raw !== 'string') return raw;
        try { return JSON.parse(raw); } catch { return raw; }
      } catch (err) {
        console.warn('[CGPT Workspace] GM_getValue failed:', err);
        return fallback;
      }
    },
    set(key, value) {
      try {
        GM_setValue(key, JSON.stringify(value));
      } catch (err) {
        console.warn('[CGPT Workspace] GM_setValue failed:', err);
      }
    }
  };

  const state = {
    folders: store.get(KEYS.folders, {}),
    assignments: store.get(KEYS.assignments, {}),
    chats: store.get(KEYS.chats, {}),
    ui: store.get(KEYS.ui, { collapsed: false }),
    renderQueued: false,
    observer: null,
    currentSidebar: null,
    lastUrl: location.href
  };

  function uid(prefix = 'f') {
    if (crypto?.randomUUID) return `${prefix}_${crypto.randomUUID()}`;
    return `${prefix}_${Date.now()}_${Math.random().toString(36).slice(2)}`;
  }

  function saveFolders() { store.set(KEYS.folders, state.folders); }
  function saveAssignments() { store.set(KEYS.assignments, state.assignments); }
  function saveChats() { store.set(KEYS.chats, state.chats); }
  function saveUI() { store.set(KEYS.ui, state.ui); }

  function ensureDefaults() {
    if (!state.folders[DEFAULT_ACTIVE_ID]) {
      state.folders[DEFAULT_ACTIVE_ID] = {
        id: DEFAULT_ACTIVE_ID,
        name: 'ACTIVE',
        icon: '⚡',
        color: '#7c3aed',
        pinned: true,
        expanded: true,
        order: 0
      };
      saveFolders();
    }
  }

  function migrateFromV9Once() {
    if (store.get(KEYS.migrated, false)) return;
    store.set(KEYS.migrated, true);

    try {
      const oldFolders = store.get('cgpt_folders_v9', null);
      const oldAssign = store.get('cgpt_assign_v9', null);
      let changed = false;

      if (oldFolders && typeof oldFolders === 'object') {
        Object.values(oldFolders).forEach((folder) => {
          if (!folder || folder.id === 'uncategorized') return;
          if (state.folders[folder.id]) return;
          state.folders[folder.id] = {
            id: folder.id,
            name: folder.name || 'Folder',
            icon: folder.icon || '📁',
            color: folder.color || '#66aaff',
            pinned: !!folder.pinned,
            expanded: folder.expanded !== false,
            order: Number.isFinite(folder.order) ? folder.order : Date.now()
          };
          changed = true;
        });
      }

      if (oldAssign && typeof oldAssign === 'object') {
        Object.entries(oldAssign).forEach(([chatId, folderId]) => {
          if (!chatId || !folderId || folderId === 'uncategorized') return;
          if (!state.folders[folderId]) return;
          if (state.assignments[chatId]) return;
          state.assignments[chatId] = folderId;
          if (!state.chats[chatId]) {
            state.chats[chatId] = {
              id: chatId,
              href: `/c/${chatId}`,
              title: `Chat ${chatId.slice(0, 8)}`,
              addedAt: Date.now(),
              updatedAt: Date.now()
            };
          }
          changed = true;
        });
      }

      if (changed) {
        saveFolders();
        saveAssignments();
        saveChats();
      }
    } catch (err) {
      console.warn('[CGPT Workspace] v9 migration failed:', err);
    }
  }

  function getSidebar() {
    const labelled = [
      document.querySelector('nav[aria-label="历史聊天记录"]'),
      document.querySelector('nav[aria-label="Chat history"]')
    ].filter(Boolean);

    if (labelled.length) return labelled[0];

    const navs = [...document.querySelectorAll('nav')]
      .filter((n) => n.id !== 'stage-sidebar-tiny-bar');

    const withChats = navs.find((n) =>
      [...n.querySelectorAll('a[href*="/c/"]')]
        .some((a) => !a.closest(`#${APP_ID}`))
    );
    if (withChats) return withChats;

    const sidebarLike = navs.find((n) => {
      const cls = typeof n.className === 'string' ? n.className : '';
      return /sidebar|scrollport/i.test(cls) && n.getBoundingClientRect().width > 120;
    });
    return sidebarLike || null;
  }

  function getConversationIdFromHref(href) {
    try {
      const url = new URL(href, location.origin);
      const m = url.pathname.match(/\/c\/([\w-]+)/i);
      return m ? m[1] : null;
    } catch {
      const m = String(href || '').match(/\/c\/([\w-]+)/i);
      return m ? m[1] : null;
    }
  }

  function cleanTitle(title) {
    let t = String(title || '').replace(/\s+/g, ' ').trim();
    t = t.replace(/\s*[-–—|]\s*ChatGPT\s*$/i, '').trim();
    if (/^(ChatGPT|New chat|新聊天)$/i.test(t)) return '';
    return t;
  }

  function titleFromNativeLink(id) {
    const links = document.querySelectorAll(`a[href*="/c/${CSS.escape(id)}"]`);
    for (const a of links) {
      if (a.closest(`#${APP_ID}`)) continue;
      const title = cleanTitle(a.getAttribute('title') || a.textContent || '');
      if (title) return title;
    }
    return '';
  }

  function getCurrentConversation() {
    const id = getConversationIdFromHref(location.href);
    if (!id) return null;

    const nativeTitle = titleFromNativeLink(id);
    const pageTitle = cleanTitle(document.title);
    const cachedTitle = state.chats[id]?.title;
    const title = nativeTitle || pageTitle || cachedTitle || `Chat ${id.slice(0, 8)}`;

    return {
      id,
      title,
      href: `${location.pathname}${location.search}${location.hash}`,
      updatedAt: Date.now()
    };
  }

  function cacheCurrentConversation() {
    const chat = getCurrentConversation();
    if (!chat) return null;

    const prev = state.chats[chat.id] || {};
    state.chats[chat.id] = {
      ...prev,
      ...chat,
      addedAt: prev.addedAt || Date.now()
    };
    saveChats();
    return state.chats[chat.id];
  }

  function refreshCachedTitlesFromNative() {
    const sidebar = getSidebar();
    if (!sidebar) return false;

    let changed = false;
    const links = sidebar.querySelectorAll('a[href*="/c/"]');
    links.forEach((a) => {
      if (a.closest(`#${APP_ID}`)) return;
      const id = getConversationIdFromHref(a.getAttribute('href') || '');
      if (!id || !state.chats[id]) return;
      const title = cleanTitle(a.getAttribute('title') || a.textContent || '');
      if (title && state.chats[id].title !== title) {
        state.chats[id].title = title;
        state.chats[id].updatedAt = Date.now();
        changed = true;
      }
      const href = a.getAttribute('href');
      if (href && state.chats[id].href !== href) {
        state.chats[id].href = href;
        changed = true;
      }
    });

    if (changed) saveChats();
    return changed;
  }

  function sortedFolders() {
    return Object.values(state.folders).sort((a, b) => {
      const pinDiff = Number(!!b.pinned) - Number(!!a.pinned);
      if (pinDiff) return pinDiff;
      return (a.order || 0) - (b.order || 0);
    });
  }

  function chatsInFolder(folderId) {
    return Object.entries(state.assignments)
      .filter(([, fid]) => fid === folderId)
      .map(([id]) => state.chats[id])
      .filter(Boolean)
      .sort((a, b) => (b.addedAt || 0) - (a.addedAt || 0));
  }

  function assignChat(chat, folderId) {
    if (!chat || !state.folders[folderId]) return;
    const prev = state.chats[chat.id] || {};
    state.chats[chat.id] = {
      ...prev,
      ...chat,
      addedAt: prev.addedAt || Date.now(),
      updatedAt: Date.now()
    };
    state.assignments[chat.id] = folderId;
    saveChats();
    saveAssignments();
    queueRender();
  }

  function removeChat(chatId) {
    delete state.assignments[chatId];
    saveAssignments();
    queueRender();
  }

  function addCurrentTo(folderId = DEFAULT_ACTIVE_ID) {
    const chat = cacheCurrentConversation();
    if (!chat) {
      toast('这个页面还不是一个已保存的对话。先发一条消息，让 ChatGPT 生成对话 ID 后再加。');
      return;
    }
    assignChat(chat, folderId);
    toast(`已加入 ${state.folders[folderId]?.icon || '📁'} ${state.folders[folderId]?.name || 'folder'}`);
  }

  function injectStyle() {
    if (document.getElementById(STYLE_ID)) return;
    const style = document.createElement('style');
    style.id = STYLE_ID;
    style.textContent = `
      #${APP_ID} {
        --ws-fg: var(--text-primary, #ececec);
        --ws-muted: var(--text-secondary, #a0a0a0);
        --ws-border: color-mix(in srgb, var(--ws-fg) 20%, transparent);
        --ws-hover: color-mix(in srgb, var(--ws-fg) 9%, transparent);
        --ws-bg: color-mix(in srgb, var(--main-surface-secondary, #202123) 94%, transparent);
        box-sizing: border-box;
        margin: 6px 8px 8px;
        border: 1px solid var(--ws-border);
        border-radius: 10px;
        background: var(--ws-bg);
        color: var(--ws-fg);
        overflow: hidden;
        flex: 0 0 auto;
        font-family: inherit;
      }
      #${APP_ID} * { box-sizing: border-box; }
      #${APP_ID} button, #${APP_ID} input { font: inherit; }
      #${APP_ID} .ws-header {
        display: flex;
        align-items: center;
        gap: 6px;
        min-height: 38px;
        padding: 5px 6px 5px 9px;
      }
      #${APP_ID} .ws-title {
        flex: 1;
        min-width: 0;
        font-size: 13px;
        font-weight: 650;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
      }
      #${APP_ID} .ws-count { color: var(--ws-muted); font-weight: 500; }
      #${APP_ID} .ws-icon-btn, #${APP_ID} .ws-small-btn {
        border: 0;
        background: transparent;
        color: var(--ws-muted);
        border-radius: 7px;
        cursor: pointer;
      }
      #${APP_ID} .ws-icon-btn { min-width: 28px; height: 28px; padding: 0 6px; }
      #${APP_ID} .ws-small-btn { min-width: 24px; height: 24px; padding: 0 5px; }
      #${APP_ID} .ws-icon-btn:hover, #${APP_ID} .ws-small-btn:hover { background: var(--ws-hover); color: var(--ws-fg); }
      #${APP_ID} .ws-body {
        max-height: min(340px, 42vh);
        overflow: auto;
        padding: 0 6px 7px;
      }
      #${APP_ID}.ws-collapsed .ws-body { display: none; }
      #${APP_ID} .ws-folder { margin-top: 2px; }
      #${APP_ID} .ws-folder-head {
        display: flex;
        align-items: center;
        gap: 5px;
        min-height: 30px;
        padding: 3px 3px 3px 7px;
        border-radius: 7px;
        cursor: pointer;
      }
      #${APP_ID} .ws-folder-head:hover { background: var(--ws-hover); }
      #${APP_ID} .ws-folder-name {
        flex: 1;
        min-width: 0;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
        font-size: 13px;
      }
      #${APP_ID} .ws-folder-count { color: var(--ws-muted); font-size: 11px; }
      #${APP_ID} .ws-folder-chats { padding-left: 13px; }
      #${APP_ID} .ws-chat-row {
        display: flex;
        align-items: center;
        gap: 4px;
        min-height: 29px;
        border-radius: 7px;
        padding: 2px 3px 2px 7px;
      }
      #${APP_ID} .ws-chat-row:hover { background: var(--ws-hover); }
      #${APP_ID} .ws-chat-link {
        flex: 1;
        min-width: 0;
        color: var(--ws-fg);
        text-decoration: none;
        font-size: 12.5px;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
      }
      #${APP_ID} .ws-chat-row .ws-chat-menu { opacity: 0; }
      #${APP_ID} .ws-chat-row:hover .ws-chat-menu, #${APP_ID} .ws-chat-menu:focus { opacity: 1; }
      #${APP_ID} .ws-empty {
        padding: 6px 8px 8px 25px;
        color: var(--ws-muted);
        font-size: 12px;
      }
      #${MENU_ID} {
        position: fixed;
        z-index: 2147483646;
        min-width: 210px;
        max-width: min(340px, calc(100vw - 20px));
        max-height: min(500px, calc(100vh - 20px));
        overflow: auto;
        padding: 6px;
        border-radius: 10px;
        border: 1px solid color-mix(in srgb, currentColor 20%, transparent);
        background: var(--main-surface-primary, #202123);
        color: var(--text-primary, #ececec);
        box-shadow: 0 8px 30px rgba(0,0,0,.35);
        font-family: inherit;
      }
      #${MENU_ID} .ws-menu-title { padding: 7px 9px 5px; opacity: .65; font-size: 11px; }
      #${MENU_ID} button {
        display: block;
        width: 100%;
        border: 0;
        background: transparent;
        color: inherit;
        text-align: left;
        padding: 8px 9px;
        border-radius: 7px;
        cursor: pointer;
        font: inherit;
        font-size: 13px;
      }
      #${MENU_ID} button:hover { background: color-mix(in srgb, currentColor 9%, transparent); }
      #${MENU_ID} .ws-danger { color: #ff6b6b; }
      .${APP_ID}-toast {
        position: fixed;
        left: 50%;
        bottom: 26px;
        transform: translateX(-50%);
        z-index: 2147483647;
        padding: 9px 13px;
        border-radius: 9px;
        background: rgba(20,20,20,.94);
        color: #fff;
        box-shadow: 0 5px 20px rgba(0,0,0,.28);
        font: 13px/1.35 system-ui, sans-serif;
        pointer-events: none;
      }
    `;
    document.head.appendChild(style);
  }

  function el(tag, className, text) {
    const node = document.createElement(tag);
    if (className) node.className = className;
    if (text !== undefined) node.textContent = text;
    return node;
  }

  function iconButton(text, title, handler, className = 'ws-icon-btn') {
    const b = el('button', className, text);
    b.type = 'button';
    b.title = title;
    b.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      handler(e);
    });
    return b;
  }

  function totalAssigned() {
    return Object.keys(state.assignments).length;
  }

  function render() {
    const root = document.getElementById(APP_ID);
    if (!root) return;

    injectStyle();
    root.innerHTML = '';
    root.classList.toggle('ws-collapsed', !!state.ui.collapsed);

    const header = el('div', 'ws-header');
    const title = el('div', 'ws-title');
    title.innerHTML = `⚡ 工作区 <span class="ws-count">${totalAssigned()}</span>`;
    header.appendChild(title);

    header.appendChild(iconButton('＋当前', '把当前对话加入工作区', (e) => openAddCurrentMenu(e.currentTarget)));
    header.appendChild(iconButton('📁＋', '新建文件夹', () => createFolderPrompt()));
    header.appendChild(iconButton(state.ui.collapsed ? '▾' : '▴', state.ui.collapsed ? '展开' : '折叠', () => {
      state.ui.collapsed = !state.ui.collapsed;
      saveUI();
      render();
    }));

    root.appendChild(header);

    const body = el('div', 'ws-body');
    for (const folder of sortedFolders()) body.appendChild(renderFolder(folder));
    root.appendChild(body);
  }

  function renderFolder(folder) {
    const wrap = el('div', 'ws-folder');
    const chats = chatsInFolder(folder.id);

    const head = el('div', 'ws-folder-head');
    if (folder.color) head.style.boxShadow = `inset 3px 0 0 ${folder.color}`;

    const arrow = el('span', '', folder.expanded === false ? '▸' : '▾');
    arrow.style.opacity = '.65';
    arrow.style.fontSize = '11px';
    head.appendChild(arrow);

    const name = el('div', 'ws-folder-name', `${folder.icon || '📁'} ${folder.name}`);
    head.appendChild(name);
    head.appendChild(el('span', 'ws-folder-count', String(chats.length)));

    head.appendChild(iconButton('＋', `把当前对话加入 ${folder.name}`, () => addCurrentTo(folder.id), 'ws-small-btn'));
    head.appendChild(iconButton('⋯', `${folder.name} 菜单`, (e) => openFolderMenu(e.currentTarget, folder), 'ws-small-btn'));

    const toggleFolder = (e) => {
      if (e.target.closest('button')) return;
      folder.expanded = folder.expanded === false;
      saveFolders();
      render();
    };
    head.addEventListener('click', toggleFolder);
    wrap.appendChild(head);

    if (folder.expanded !== false) {
      const list = el('div', 'ws-folder-chats');
      if (!chats.length) {
        list.appendChild(el('div', 'ws-empty', '打开一个对话，然后点这里的 ＋')); 
      } else {
        chats.forEach((chat) => list.appendChild(renderChat(chat, folder)));
      }
      wrap.appendChild(list);
    }

    return wrap;
  }

  function findNativeConversationLink(chatId) {
    const candidates = [...document.querySelectorAll('a[href*="/c/"]')].filter((a) => {
      if (a.closest(`#${APP_ID}`)) return false;
      return getConversationIdFromHref(a.getAttribute('href') || a.href || '') === chatId;
    });

    if (!candidates.length) return null;

    // Prefer ChatGPT's real history sidebar link, because its React/Next handler
    // is the most reliable way to get the same no-full-page-refresh navigation.
    const sidebar = getSidebar();
    const inSidebar = sidebar && candidates.find((a) => sidebar.contains(a));
    if (inSidebar) return inSidebar;

    // Otherwise prefer a visible native copy (project/pinned/search UI may expose one).
    return candidates.find((a) => a.getClientRects().length > 0) || candidates[0];
  }

  function navigateToChat(chat) {
    if (!chat?.id) return;
    if (getConversationIdFromHref(location.href) === chat.id) return;

    const targetHref = chat.href || `/c/${chat.id}`;
    const nativeLink = findNativeConversationLink(chat.id);

    if (nativeLink) {
      // Piggyback ChatGPT's own SPA navigation instead of trying to emulate its
      // private router with pushState/popstate. Programmatic .click() still runs
      // the native link's React event path.
      nativeLink.click();

      // Safety net: if OpenAI changes the native handler and the synthetic click
      // no longer navigates, fall back to a normal page load rather than doing nothing.
      setTimeout(() => {
        if (getConversationIdFromHref(location.href) !== chat.id) {
          location.assign(new URL(targetHref, location.origin).href);
        }
      }, 1200);
      return;
    }

    // ChatGPT lazy-loads/virtualizes parts of the sidebar. If this target chat has
    // no native route element mounted right now, there is no stable public router
    // API to call, so retain the reliable full-navigation fallback.
    location.assign(new URL(targetHref, location.origin).href);
  }

  function renderChat(chat, folder) {
    const row = el('div', 'ws-chat-row');

    const link = el('a', 'ws-chat-link', chat.title || `Chat ${chat.id.slice(0, 8)}`);
    link.href = chat.href || `/c/${chat.id}`;
    link.title = chat.title || chat.id;
    link.addEventListener('click', (e) => {
      // Preserve normal browser semantics for Ctrl/Cmd-click, Shift-click, Alt-click
      // and middle click. Only plain left-click is replaced with the SPA bridge.
      if (e.button !== 0 || e.ctrlKey || e.metaKey || e.shiftKey || e.altKey) return;
      e.preventDefault();
      e.stopPropagation();
      closeMenu();
      navigateToChat(chat);
    });
    row.appendChild(link);

    const menuBtn = iconButton('⋯', '移动 / 重命名 / 移除', (e) => openChatMenu(e.currentTarget, chat, folder), 'ws-small-btn ws-chat-menu');
    row.appendChild(menuBtn);
    return row;
  }

  function createFolderPrompt() {
    const name = prompt('新文件夹名称');
    if (!name?.trim()) return;
    const icon = prompt('图标（可留空，例如 ⚡ / 🧪 / 🎮）', '📁');
    const id = uid('folder');
    const maxOrder = Math.max(0, ...Object.values(state.folders).map((f) => Number(f.order) || 0));
    state.folders[id] = {
      id,
      name: name.trim(),
      icon: (icon || '📁').trim() || '📁',
      color: '#66aaff',
      pinned: false,
      expanded: true,
      order: maxOrder + 1
    };
    saveFolders();
    render();
  }

  function closeMenu() {
    document.getElementById(MENU_ID)?.remove();
  }

  function openMenu(anchor, build) {
    closeMenu();
    const menu = el('div');
    menu.id = MENU_ID;
    build(menu);
    document.body.appendChild(menu);

    const rect = anchor.getBoundingClientRect();
    const mr = menu.getBoundingClientRect();
    let left = rect.right + 6;
    let top = rect.bottom + 4;

    if (left + mr.width > window.innerWidth - 8) left = Math.max(8, rect.left - mr.width - 6);
    if (top + mr.height > window.innerHeight - 8) top = Math.max(8, window.innerHeight - mr.height - 8);

    menu.style.left = `${left}px`;
    menu.style.top = `${top}px`;
  }

  function menuTitle(menu, text) {
    menu.appendChild(el('div', 'ws-menu-title', text));
  }

  function menuButton(menu, text, handler, danger = false) {
    const b = el('button', danger ? 'ws-danger' : '', text);
    b.type = 'button';
    b.addEventListener('click', () => {
      closeMenu();
      handler();
    });
    menu.appendChild(b);
  }

  function openAddCurrentMenu(anchor) {
    const chat = cacheCurrentConversation();
    if (!chat) {
      toast('这个页面还不是一个已保存的对话。');
      return;
    }

    openMenu(anchor, (menu) => {
      menuTitle(menu, `加入：${chat.title}`);
      for (const folder of sortedFolders()) {
        const already = state.assignments[chat.id] === folder.id ? ' ✓' : '';
        menuButton(menu, `${folder.icon || '📁'} ${folder.name}${already}`, () => assignChat(chat, folder.id));
      }
    });
  }

  function openChatMenu(anchor, chat, currentFolder) {
    openMenu(anchor, (menu) => {
      menuTitle(menu, chat.title || chat.id);

      for (const folder of sortedFolders()) {
        if (folder.id === currentFolder.id) continue;
        menuButton(menu, `移动到 ${folder.icon || '📁'} ${folder.name}`, () => assignChat(chat, folder.id));
      }

      menuButton(menu, '重命名显示名', () => {
        const title = prompt('显示名', chat.title || '');
        if (!title?.trim()) return;
        state.chats[chat.id].title = title.trim();
        state.chats[chat.id].updatedAt = Date.now();
        saveChats();
        render();
      });

      menuButton(menu, '从工作区移除', () => removeChat(chat.id), true);
    });
  }

  function openFolderMenu(anchor, folder) {
    openMenu(anchor, (menu) => {
      menuTitle(menu, `${folder.icon || '📁'} ${folder.name}`);

      menuButton(menu, folder.pinned ? '取消置顶文件夹' : '置顶文件夹', () => {
        folder.pinned = !folder.pinned;
        saveFolders();
        render();
      });

      menuButton(menu, '重命名', () => {
        const name = prompt('文件夹名称', folder.name);
        if (!name?.trim()) return;
        folder.name = name.trim();
        saveFolders();
        render();
      });

      menuButton(menu, '修改图标', () => {
        const icon = prompt('图标', folder.icon || '📁');
        if (icon === null) return;
        folder.icon = icon.trim() || '📁';
        saveFolders();
        render();
      });

      menuButton(menu, '修改颜色', () => {
        const color = prompt('颜色（CSS / hex，例如 #66aaff）', folder.color || '#66aaff');
        if (!color?.trim()) return;
        folder.color = color.trim();
        saveFolders();
        render();
      });

      if (folder.id !== DEFAULT_ACTIVE_ID) {
        menuButton(menu, '删除文件夹', () => {
          const chats = chatsInFolder(folder.id);
          const target = state.folders[DEFAULT_ACTIVE_ID];
          const msg = chats.length
            ? `删除「${folder.name}」？其中 ${chats.length} 个对话会移到 ${target.icon} ${target.name}。`
            : `删除「${folder.name}」？`;
          if (!confirm(msg)) return;
          for (const chat of chats) state.assignments[chat.id] = DEFAULT_ACTIVE_ID;
          delete state.folders[folder.id];
          saveFolders();
          saveAssignments();
          render();
        }, true);
      }
    });
  }

  function toast(message) {
    const old = document.querySelector(`.${APP_ID}-toast`);
    old?.remove();
    const node = el('div', `${APP_ID}-toast`, message);
    document.body.appendChild(node);
    setTimeout(() => node.remove(), 2200);
  }

  function ensureMounted() {
    const sidebar = getSidebar();
    if (!sidebar) return false;

    let root = document.getElementById(APP_ID);
    if (!root) {
      root = el('section');
      root.id = APP_ID;
      root.setAttribute('data-shuu-cgpt-workspace', 'true');
      sidebar.prepend(root);
    } else if (root.parentElement !== sidebar) {
      sidebar.prepend(root);
    }

    state.currentSidebar = sidebar;
    render();
    return true;
  }

  function queueRender(delay = 80) {
    if (state.renderQueued) return;
    state.renderQueued = true;
    setTimeout(() => {
      state.renderQueued = false;
      ensureMounted();
    }, delay);
  }

  function onNavigation() {
    if (state.lastUrl === location.href) return;
    state.lastUrl = location.href;
    closeMenu();
    setTimeout(() => {
      cacheCurrentConversation();
      refreshCachedTitlesFromNative();
      queueRender();
    }, 180);
  }

  function hookHistory() {
    for (const name of ['pushState', 'replaceState']) {
      const original = history[name];
      if (original.__shuuWrapped) continue;
      const wrapped = function (...args) {
        const result = original.apply(this, args);
        queueMicrotask(onNavigation);
        return result;
      };
      wrapped.__shuuWrapped = true;
      history[name] = wrapped;
    }
    window.addEventListener('popstate', () => queueMicrotask(onNavigation));
  }

  function observeDom() {
    state.observer?.disconnect();
    const observer = new MutationObserver((mutations) => {
      const relevant = mutations.some((m) => {
        const target = m.target instanceof Element ? m.target : m.target.parentElement;
        return target && !target.closest?.(`#${APP_ID}`) && !target.closest?.(`#${MENU_ID}`);
      });
      if (!relevant) return;

      const changedTitles = refreshCachedTitlesFromNative();
      const sidebar = getSidebar();
      const root = document.getElementById(APP_ID);
      if (!root || (sidebar && root.parentElement !== sidebar) || changedTitles) queueRender(120);
      onNavigation();
    });
    observer.observe(document.body, { childList: true, subtree: true, characterData: true });
    state.observer = observer;
  }

  document.addEventListener('click', (e) => {
    const menu = document.getElementById(MENU_ID);
    if (menu && !menu.contains(e.target) && !e.target.closest(`#${APP_ID} button`)) closeMenu();
  }, true);

  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') closeMenu();
  });

  function start() {
    ensureDefaults();
    migrateFromV9Once();
    injectStyle();
    hookHistory();
    cacheCurrentConversation();
    refreshCachedTitlesFromNative();
    ensureMounted();
    observeDom();

    // Very low-cost fallback for sidebar DOM replacement that happens without a useful mutation target.
    setInterval(() => {
      if (!document.getElementById(APP_ID) || getSidebar() !== state.currentSidebar) queueRender(0);
      onNavigation();
    }, 5000);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', start, { once: true });
  } else {
    start();
  }
})();
